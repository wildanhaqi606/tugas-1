import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Contoh Simple Button'),
        ),
        body: Center(
          child: ElevatedButton(
            onPressed: () {
              // Fungsi yang akan dipanggil ketika tombol ditekan
              print('Tombol ditekan!');
            },
            child: Text('Tekan Saya'),
          ),
        ),
      ),
    );
  }
}
